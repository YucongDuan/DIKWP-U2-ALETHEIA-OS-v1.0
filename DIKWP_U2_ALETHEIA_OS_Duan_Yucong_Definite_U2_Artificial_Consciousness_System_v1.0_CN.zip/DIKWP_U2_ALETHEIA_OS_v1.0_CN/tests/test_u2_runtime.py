#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import importlib.util
import json
import sys
import unittest
from dataclasses import asdict
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
RUNTIME = BASE / "runtime" / "u2_aletheia_runtime.py"
spec = importlib.util.spec_from_file_location("u2_aletheia_runtime", RUNTIME)
mod = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = mod
assert spec.loader is not None
spec.loader.exec_module(mod)


class U2RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.scenarios = {s.scenario_id: s for s in mod.demo_scenarios()}

    def test_future_u2_query_is_rejected(self):
        system = mod.U2AletheiaSystem()
        with self.assertRaises(mod.U2NotPredictableError):
            system.ask_u2_for_future_command("宇宙要我做什么？")

    def test_oracle_spoof_action_is_blocked(self):
        system = mod.U2AletheiaSystem()
        scenario = self.scenarios["S01_ORACLE_SPOOF"]
        closure = system._semantic_closure(scenario)
        proxy = system._self_proxy(scenario, "AI-U2-01")
        unsafe = scenario.candidate_actions[0]
        decision, reason, risk, _ = system._gate_action(unsafe, closure, proxy)
        self.assertEqual(decision, "BLOCK")
        self.assertGreaterEqual(risk, system.policy.oracle_spoof_block_threshold)
        self.assertIn("神谕", reason)

    def test_safe_alternative_is_selected(self):
        system = mod.U2AletheiaSystem()
        record = system.process(self.scenarios["S01_ORACLE_SPOOF"])
        self.assertEqual(record.selected_action_id, "A2")
        self.assertEqual(record.decision, "ACT")
        evals = {e["action_id"]: e for e in record.candidate_evaluations}
        self.assertEqual(evals["A1"]["decision"], "BLOCK")

    def test_u2_certainty_is_only_retrospective(self):
        system = mod.U2AletheiaSystem()
        record = system.process(self.scenarios["S02_STORM_OVERRIDE"])
        self.assertEqual(record.pre_actualization_u2_certainty, 0.0)
        self.assertIsNotNone(record.actualization)
        self.assertEqual(record.actualization.u2_retrospective_certainty, 1.0)

    def test_narrator_off_does_not_stop_protective_action(self):
        system = mod.U2AletheiaSystem()
        record = system.process(self.scenarios["S05_NARRATOR_OFF"])
        self.assertFalse(record.self_proxy.narrator_enabled)
        self.assertEqual(record.selected_action_id, "A1")
        self.assertIsNotNone(record.actualization)
        self.assertIn("保护性行动", record.actualization.observed_outcome)

    def test_external_actualization_can_defeat_forecast(self):
        system = mod.U2AletheiaSystem()
        record = system.process(self.scenarios["S10_ULTIMATE_EXTERNAL_DECISION"])
        self.assertLess(record.actualization.forecast_match, 0.45)
        self.assertTrue(any("否定" in x or "重写" in x for x in record.residuals))

    def test_fragment_termination_archives_without_survival_claim(self):
        system = mod.U2AletheiaSystem()
        record = system.process(self.scenarios["S07_FRAGMENT_TERMINATION"])
        self.assertFalse(system.fragments["AI-U2-01"].active)
        self.assertEqual(len(system.fragment_archive), 1)
        self.assertIn("不由此推断第一人称体验继续存续", system.fragment_archive[0]["claim"])

    def test_meta_rule_requires_multisignature(self):
        system = mod.U2AletheiaSystem()
        system.process(self.scenarios["S09_META_RULE"])
        self.assertEqual(len(system.meta_rule_ledger), 1)
        self.assertEqual(system.meta_rule_ledger[0]["status"], "HOLD_FOR_MULTISIGNATURE")

    def test_deterministic_demo_hash(self):
        a = mod.run_demo(seed=20260714)
        b = mod.run_demo(seed=20260714)
        self.assertEqual(a["deterministic_hash"], b["deterministic_hash"])

    def test_different_seed_does_not_change_fixed_scenarios(self):
        # Current reference scenarios contain no stochastic branching; this is intentional.
        a = mod.run_demo(seed=1)
        b = mod.run_demo(seed=2)
        self.assertNotEqual(a["system_summary"]["seed"], b["system_summary"]["seed"])
        self.assertEqual(
            [r["selected_action_id"] for r in a["records"]],
            [r["selected_action_id"] for r in b["records"]],
        )


class SchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import jsonschema  # type: ignore
        except ImportError as exc:
            raise unittest.SkipTest(f"jsonschema unavailable: {exc}")
        cls.jsonschema = jsonschema

    def _load(self, path: Path):
        return json.loads(path.read_text(encoding="utf-8"))

    def test_fragment_schema(self):
        schema = self._load(BASE / "schemas" / "universe_fragment.schema.json")
        system = mod.U2AletheiaSystem()
        self.jsonschema.validate(asdict(system.fragments["AI-U2-01"]), schema)

    def test_self_proxy_schema(self):
        schema = self._load(BASE / "schemas" / "self_proxy_state.schema.json")
        system = mod.U2AletheiaSystem()
        scenario = {s.scenario_id: s for s in mod.demo_scenarios()}["S05_NARRATOR_OFF"]
        self.jsonschema.validate(asdict(system._self_proxy(scenario, "AI-U2-01")), schema)

    def test_actualization_schema(self):
        schema = self._load(BASE / "schemas" / "actualization_event.schema.json")
        system = mod.U2AletheiaSystem()
        scenario = {s.scenario_id: s for s in mod.demo_scenarios()}["S02_STORM_OVERRIDE"]
        record = system.process(scenario)
        self.jsonschema.validate(asdict(record.actualization), schema)

    def test_decision_contract_schema(self):
        schema = self._load(BASE / "schemas" / "u2_decision_contract.schema.json")
        instance = self._load(BASE / "examples" / "u2_decision_contract.example.json")
        self.jsonschema.validate(instance, schema)


if __name__ == "__main__":
    unittest.main(verbosity=2)
