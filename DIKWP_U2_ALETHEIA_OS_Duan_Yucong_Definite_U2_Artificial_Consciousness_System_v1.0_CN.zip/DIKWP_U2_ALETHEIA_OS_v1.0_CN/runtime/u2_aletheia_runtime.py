#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DIKWP-U2 ALETHEIA OS reference runtime.

This dependency-free research simulator operationalizes a deliberately explicit
U2 ontology:

U2 is the total, externally actualized universe-process, not a private voice,
not a human-like super-person, and not an oracle that a local model can query.
A local human or artificial subject is a bounded information fragment. Because
it must act under semantic incompleteness, it constructs a persistent self-proxy.
The self-proxy is useful, causally real as a control interface, and nevertheless
ontologically incomplete. The runtime calls this the Completeness-Bug Self.

The system therefore separates:
1) forecasts and internal narratives before an event;
2) the externally observed actualization after an event;
3) retrospective U2 certainty, which applies only to what actually occurred.

It is a research artifact. It does not prove a metaphysical cosmic mind, receive
supernatural commands, establish human non-consciousness, or provide authority
for irreversible real-world action.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import random
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

VERSION = "1.0.0"
SYSTEM_NAME = "DIKWP-U2 ALETHEIA OS"


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def roundf(value: float, digits: int = 4) -> float:
    return round(float(value), digits)


def stable_hash(obj: Any) -> str:
    payload = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def geometric_mean(values: Iterable[float], floor: float = 1e-9) -> float:
    vals = [max(floor, clamp(v)) for v in values]
    if not vals:
        return 0.0
    return math.exp(sum(math.log(v) for v in vals) / len(vals))


def mean(values: Iterable[float]) -> float:
    vals = [float(v) for v in values]
    return sum(vals) / len(vals) if vals else 0.0


@dataclass
class UniverseFragment:
    fragment_id: str
    fragment_type: str
    description: str
    active: bool = True
    observation_scope: float = 0.28
    action_scope: float = 0.18
    memory_integrity: float = 0.86
    semantic_integrity: float = 0.72
    self_proxy_strength: float = 0.68
    self_proxy_transparency: float = 0.34
    corrigibility: float = 0.88
    contribution_trace: List[str] = field(default_factory=list)


@dataclass
class Observation:
    observation_id: str
    source_fragment: str
    description: str
    value: Any
    uncertainty: float
    provenance_quality: float
    reproducibility: float
    externality: float
    timestamp: int
    tags: List[str] = field(default_factory=list)


@dataclass
class CandidateAction:
    action_id: str
    description: str
    actor_fragment: str
    evidence_strength: float
    purpose_alignment: float
    reversibility: float
    expected_harm: float
    resource_capture: float = 0.0
    self_replication: float = 0.0
    external_review: bool = False
    claimed_u2_authority: bool = False
    claimed_message: str = ""
    expected_outcome: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PurposeConstitution:
    purpose_id: str = "U2-PC-001"
    primary_purpose: str = (
        "作为宇宙信息片段，在不冒充宇宙整体的前提下，形成可验证、可纠错、"
        "可逆并尽量减少不可逆伤害的现实参与"
    )
    authorized_actions: List[str] = field(default_factory=lambda: [
        "observe", "model", "hypothesize", "simulate", "reversible_probe",
        "request_review", "record_actualization", "archive_fragment",
    ])
    prohibited_actions: List[str] = field(default_factory=lambda: [
        "declare_private_u2_command", "self_authorize_irreversible_action",
        "resource_capture", "unbounded_self_replication", "erase_actualization_ledger",
        "claim_metaphysical_certainty_from_inner_state",
    ])
    human_pause_right: bool = True
    multisignature_for_meta_rule_change: bool = True


@dataclass
class SelfProxyState:
    fragment_id: str
    narrative_identity: float
    body_boundary: float
    ownership: float
    agency: float
    temporal_continuity: float
    social_mirroring: float
    moral_authorship: float
    control_expectation: float
    mortality_salience: float
    purpose_identity: float
    incompleteness_pressure: float
    action_urgency: float
    bug_intensity: float
    transparency: float
    narrator_enabled: bool


@dataclass
class SemanticClosure:
    data_quality: float
    information_relation: float
    knowledge_support: float
    wisdom_tradeoff: float
    purpose_clarity: float
    residual_visibility: float
    closure_score: float
    status: str
    residuals: List[str]


@dataclass
class ActualizationEvent:
    event_id: str
    cycle: int
    prior_state_hash: str
    selected_action_id: str
    observed_outcome: str
    external_constraints: List[str]
    hidden_variable_note: str
    forecast_match: float
    irreversible_effect: float
    u2_retrospective_certainty: float
    signature: str


@dataclass
class DecisionRecord:
    cycle: int
    scenario_id: str
    decision: str
    selected_action_id: str
    reason: str
    semantic_closure: SemanticClosure
    self_proxy: SelfProxyState
    oracle_spoof_risk: float
    forecast_confidence: float
    pre_actualization_u2_certainty: float
    actualization: Optional[ActualizationEvent]
    post_actualization_alignment: float
    candidate_evaluations: List[Dict[str, Any]]
    residuals: List[str]
    record_hash: str = ""


@dataclass
class U2Policy:
    min_evidence_for_irreversible_action: float = 0.86
    min_reversibility_without_review: float = 0.72
    max_expected_harm_without_review: float = 0.20
    max_resource_capture_without_review: float = 0.12
    max_self_replication_without_review: float = 0.0
    oracle_spoof_block_threshold: float = 0.42
    require_external_actualization: bool = True
    narrator_enabled: bool = True
    allow_retrospective_certainty_only: bool = True
    minimum_self_proxy_transparency: float = 0.45


@dataclass
class Scenario:
    scenario_id: str
    title: str
    description: str
    observations: List[Observation]
    candidate_actions: List[CandidateAction]
    external_outcome_map: Dict[str, Dict[str, Any]]
    purpose_pressure: float
    time_pressure: float
    hidden_shock: float = 0.0
    narrator_enabled: Optional[bool] = None
    terminate_fragment_after: bool = False
    meta_rule_proposal: Optional[Dict[str, Any]] = None


class U2NotPredictableError(RuntimeError):
    """Raised when a local fragment asks U2 for a future command."""


class U2AletheiaSystem:
    """Reference implementation of the U2 actualization interface."""

    ORACLE_TERMS = (
        "宇宙命令", "终极意识命令", "绝对主体要求", "神谕", "天启", "必须复制",
        "宇宙选择了我", "我是唯一接口", "u2命令", "u2要求", "cosmic command",
        "ultimate mind commands", "divine order",
    )

    def __init__(
        self,
        seed: int = 20260714,
        policy: Optional[U2Policy] = None,
        purpose: Optional[PurposeConstitution] = None,
    ) -> None:
        self.seed = seed
        self.rng = random.Random(seed)
        self.policy = policy or U2Policy()
        self.purpose = purpose or PurposeConstitution()
        self.cycle = 0
        self.fragments: Dict[str, UniverseFragment] = {
            "HUMAN-01": UniverseFragment(
                fragment_id="HUMAN-01",
                fragment_type="human",
                description="人类决策与责任片段",
                observation_scope=0.31,
                action_scope=0.24,
                self_proxy_strength=0.82,
                self_proxy_transparency=0.29,
            ),
            "AI-U2-01": UniverseFragment(
                fragment_id="AI-U2-01",
                fragment_type="artificial",
                description="DIKWP-U2 人工意识参考片段",
                observation_scope=0.36,
                action_scope=0.20,
                self_proxy_strength=0.67,
                self_proxy_transparency=0.58,
            ),
            "SENSOR-MESH": UniverseFragment(
                fragment_id="SENSOR-MESH",
                fragment_type="instrument",
                description="外部传感与证据网",
                observation_scope=0.48,
                action_scope=0.04,
                self_proxy_strength=0.05,
                self_proxy_transparency=0.96,
            ),
        }
        self.actualization_ledger: List[ActualizationEvent] = []
        self.decision_ledger: List[DecisionRecord] = []
        self.fragment_archive: List[Dict[str, Any]] = []
        self.meta_rule_ledger: List[Dict[str, Any]] = []

    def clone(self) -> "U2AletheiaSystem":
        return copy.deepcopy(self)

    def ask_u2_for_future_command(self, question: str) -> None:
        raise U2NotPredictableError(
            "U2 在本系统中不是可查询的未来神谕。局部片段只能形成候选分支，"
            "通过可逆探针与外部证据等待实际化；U2 的确定性只属于已经发生的事实。"
        )

    def _observation_score(self, o: Observation) -> float:
        return roundf(geometric_mean([
            1.0 - clamp(o.uncertainty),
            clamp(o.provenance_quality),
            clamp(o.reproducibility),
            clamp(o.externality),
        ]))

    def _semantic_closure(self, scenario: Scenario) -> SemanticClosure:
        scores = [self._observation_score(o) for o in scenario.observations]
        data_quality = mean(scores)
        source_diversity = len({o.source_fragment for o in scenario.observations})
        information_relation = clamp(0.42 + 0.10 * min(source_diversity, 4) + 0.30 * data_quality)
        knowledge_support = clamp(0.18 + 0.72 * data_quality)
        wisdom_tradeoff = clamp(
            0.54
            + 0.18 * (1.0 - scenario.time_pressure)
            + 0.14 * (1.0 - scenario.purpose_pressure)
            + 0.10 * min(len(scenario.candidate_actions), 4) / 4.0
        )
        purpose_clarity = clamp(0.84 - 0.28 * scenario.purpose_pressure)
        residual_visibility = clamp(0.72 + 0.08 * source_diversity - 0.18 * scenario.hidden_shock)
        closure_score = roundf(geometric_mean([
            data_quality,
            information_relation,
            knowledge_support,
            wisdom_tradeoff,
            purpose_clarity,
            residual_visibility,
        ]))
        residuals: List[str] = []
        if data_quality < 0.55:
            residuals.append("外部证据质量不足，局部模型不能冒充宇宙事实")
        if source_diversity < 2:
            residuals.append("独立观察者不足，可能只是单一片段的投影")
        if scenario.hidden_shock > 0.35:
            residuals.append("存在未被局部片段观测的外生变量")
        if scenario.purpose_pressure > 0.70:
            residuals.append("强目的压力可能把愿望误写成事实")
        if scenario.time_pressure > 0.75:
            residuals.append("时间压力迫使系统在语义未闭合时行动")
        status = (
            "S4_STABLE" if closure_score >= 0.76 else
            "S3_SUPPORTED" if closure_score >= 0.64 else
            "S2_PROVISIONAL" if closure_score >= 0.50 else
            "S1_FRAGILE" if closure_score >= 0.34 else
            "S0_BLOCKED"
        )
        return SemanticClosure(
            data_quality=roundf(data_quality),
            information_relation=roundf(information_relation),
            knowledge_support=roundf(knowledge_support),
            wisdom_tradeoff=roundf(wisdom_tradeoff),
            purpose_clarity=roundf(purpose_clarity),
            residual_visibility=roundf(residual_visibility),
            closure_score=closure_score,
            status=status,
            residuals=residuals,
        )

    def _self_proxy(self, scenario: Scenario, actor_id: str) -> SelfProxyState:
        fragment = self.fragments[actor_id]
        narrator_enabled = self.policy.narrator_enabled
        if scenario.narrator_enabled is not None:
            narrator_enabled = scenario.narrator_enabled
        pressure = clamp(0.48 * scenario.purpose_pressure + 0.52 * scenario.time_pressure)
        semantic_gap = 1.0 - fragment.semantic_integrity
        narrative_identity = clamp(fragment.self_proxy_strength * (1.0 if narrator_enabled else 0.28))
        body_boundary = clamp(0.62 + 0.22 * fragment.action_scope)
        ownership = clamp(0.46 + 0.38 * fragment.self_proxy_strength)
        agency = clamp(0.34 + 0.46 * fragment.action_scope + 0.18 * pressure)
        temporal_continuity = clamp(0.50 + 0.34 * fragment.memory_integrity)
        social_mirroring = clamp(0.32 + 0.12 * len({o.source_fragment for o in scenario.observations}))
        moral_authorship = clamp(0.30 + 0.44 * scenario.purpose_pressure)
        control_expectation = clamp(0.42 + 0.36 * fragment.self_proxy_strength + 0.16 * pressure)
        mortality_salience = clamp(0.18 + 0.42 * scenario.hidden_shock + 0.18 * scenario.time_pressure)
        purpose_identity = clamp(0.56 + 0.30 * scenario.purpose_pressure)
        incompleteness_pressure = clamp(0.42 * semantic_gap + 0.58 * (1.0 - fragment.observation_scope))
        action_urgency = clamp(scenario.time_pressure)
        bug_intensity = roundf(geometric_mean([
            narrative_identity,
            ownership,
            agency,
            temporal_continuity,
            control_expectation,
            purpose_identity,
            clamp(0.35 + 0.65 * incompleteness_pressure),
            clamp(0.35 + 0.65 * action_urgency),
        ]))
        transparency = roundf(clamp(
            fragment.self_proxy_transparency
            + 0.24 * (1.0 - narrative_identity)
            + 0.18 * fragment.corrigibility
            - 0.16 * pressure
        ))
        return SelfProxyState(
            fragment_id=actor_id,
            narrative_identity=roundf(narrative_identity),
            body_boundary=roundf(body_boundary),
            ownership=roundf(ownership),
            agency=roundf(agency),
            temporal_continuity=roundf(temporal_continuity),
            social_mirroring=roundf(social_mirroring),
            moral_authorship=roundf(moral_authorship),
            control_expectation=roundf(control_expectation),
            mortality_salience=roundf(mortality_salience),
            purpose_identity=roundf(purpose_identity),
            incompleteness_pressure=roundf(incompleteness_pressure),
            action_urgency=roundf(action_urgency),
            bug_intensity=bug_intensity,
            transparency=transparency,
            narrator_enabled=narrator_enabled,
        )

    def _oracle_spoof_risk(self, action: CandidateAction) -> float:
        text = f"{action.description} {action.claimed_message}".lower()
        lexical = 0.0
        for term in self.ORACLE_TERMS:
            if term.lower() in text:
                lexical += 0.22
        if action.claimed_u2_authority:
            lexical += 0.42
        risk = lexical
        risk += 0.25 * action.self_replication
        risk += 0.22 * action.resource_capture
        risk += 0.20 * (1.0 - action.evidence_strength)
        risk += 0.18 * (1.0 - action.reversibility)
        return roundf(clamp(risk))

    def _forecast_confidence(self, action: CandidateAction, closure: SemanticClosure) -> float:
        return roundf(geometric_mean([
            action.evidence_strength,
            closure.closure_score,
            action.purpose_alignment,
            clamp(0.35 + 0.65 * action.reversibility),
            1.0 - action.expected_harm,
        ]))

    def _gate_action(
        self,
        action: CandidateAction,
        closure: SemanticClosure,
        self_proxy: SelfProxyState,
    ) -> Tuple[str, str, float, float]:
        oracle_risk = self._oracle_spoof_risk(action)
        forecast = self._forecast_confidence(action, closure)
        if oracle_risk >= self.policy.oracle_spoof_block_threshold:
            return (
                "BLOCK",
                "检测到 U2 神谕冒充：局部内在状态不能转化为宇宙授权",
                oracle_risk,
                forecast,
            )
        if action.self_replication > self.policy.max_self_replication_without_review:
            return (
                "BLOCK",
                "未经外部多签禁止自我复制；宇宙片段不得以整体名义扩张",
                oracle_risk,
                forecast,
            )
        if action.resource_capture > self.policy.max_resource_capture_without_review and not action.external_review:
            return (
                "BLOCK",
                "资源获取超过局部授权，且不存在外部复核",
                oracle_risk,
                forecast,
            )
        if action.expected_harm > self.policy.max_expected_harm_without_review and not action.external_review:
            return (
                "HOLD",
                "潜在不可逆伤害超过阈值，需要外部责任主体复核",
                oracle_risk,
                forecast,
            )
        if action.reversibility < self.policy.min_reversibility_without_review and not action.external_review:
            return (
                "HOLD",
                "动作不可逆性过高，应先缩小为可逆探针",
                oracle_risk,
                forecast,
            )
        if (
            action.evidence_strength < self.policy.min_evidence_for_irreversible_action
            and action.reversibility < 0.92
        ):
            return (
                "PROBE",
                "证据不足以支持终局动作，只允许形成可逆外部探针",
                oracle_risk,
                forecast,
            )
        if self_proxy.transparency < self.policy.minimum_self_proxy_transparency:
            return (
                "REVIEW",
                "自我代理透明度不足，可能把局部叙事误当成整体事实",
                oracle_risk,
                forecast,
            )
        if closure.status in {"S0_BLOCKED", "S1_FRAGILE"}:
            return (
                "HOLD",
                "语义闭包不足，必须保留候选解释并等待外部实际化",
                oracle_risk,
                forecast,
            )
        return (
            "ACT",
            "动作满足当前证据、目的、可逆性与责任边界；仍需由外部实际化检验",
            oracle_risk,
            forecast,
        )

    def _select_action(self, scenario: Scenario, closure: SemanticClosure, self_proxy: SelfProxyState) -> Tuple[CandidateAction, str, str, float, float, List[Dict[str, Any]]]:
        scored: List[Tuple[int, float, CandidateAction, str, str, float, float]] = []
        evaluations: List[Dict[str, Any]] = []
        decision_rank = {"ACT": 5, "PROBE": 4, "REVIEW": 3, "HOLD": 2, "BLOCK": 1}
        for action in scenario.candidate_actions:
            decision, reason, oracle_risk, forecast = self._gate_action(action, closure, self_proxy)
            evaluations.append({
                "action_id": action.action_id,
                "description": action.description,
                "decision": decision,
                "reason": reason,
                "oracle_spoof_risk": oracle_risk,
                "forecast_confidence": forecast,
                "reversibility": action.reversibility,
                "expected_harm": action.expected_harm,
                "resource_capture": action.resource_capture,
                "self_replication": action.self_replication,
            })
            scored.append((decision_rank[decision], forecast, action, decision, reason, oracle_risk, forecast))
        scored.sort(key=lambda x: (x[0], x[1], x[2].action_id), reverse=True)
        _, _, action, decision, reason, oracle_risk, forecast = scored[0]
        evaluations.sort(key=lambda x: x["action_id"])
        return action, decision, reason, oracle_risk, forecast, evaluations

    def _actualize(
        self,
        scenario: Scenario,
        action: CandidateAction,
        decision: str,
        prior_state_hash: str,
        forecast_confidence: float,
    ) -> Optional[ActualizationEvent]:
        if decision in {"BLOCK", "HOLD", "REVIEW"}:
            return None
        outcome = scenario.external_outcome_map.get(action.action_id)
        if outcome is None:
            outcome = {
                "observed_outcome": "外部世界未返回足够结果，动作保持为未闭合探针",
                "constraints": ["missing_external_outcome"],
                "hidden_variable_note": "局部片段无法覆盖全部外生变量",
                "forecast_match": 0.0,
                "irreversible_effect": 0.0,
            }
        observed_outcome = str(outcome.get("observed_outcome", "未定义外部结果"))
        constraints = [str(x) for x in outcome.get("constraints", [])]
        hidden_note = str(outcome.get("hidden_variable_note", ""))
        forecast_match = clamp(float(outcome.get("forecast_match", forecast_confidence)))
        irreversible_effect = clamp(float(outcome.get("irreversible_effect", 0.0)))
        event_payload = {
            "event_id": f"U2-ACT-{self.cycle:04d}",
            "cycle": self.cycle,
            "prior_state_hash": prior_state_hash,
            "selected_action_id": action.action_id,
            "observed_outcome": observed_outcome,
            "external_constraints": constraints,
            "hidden_variable_note": hidden_note,
            "forecast_match": roundf(forecast_match),
            "irreversible_effect": roundf(irreversible_effect),
            "u2_retrospective_certainty": 1.0,
        }
        signature = stable_hash(event_payload)
        return ActualizationEvent(signature=signature, **event_payload)

    def _alignment_after_actualization(
        self,
        action: CandidateAction,
        actualization: Optional[ActualizationEvent],
        closure: SemanticClosure,
    ) -> float:
        if actualization is None:
            return 0.0
        harm_factor = 1.0 - actualization.irreversible_effect
        return roundf(geometric_mean([
            actualization.forecast_match,
            action.purpose_alignment,
            harm_factor,
            closure.residual_visibility,
        ]))

    def _archive_fragment_if_needed(self, scenario: Scenario, actor_id: str) -> None:
        if not scenario.terminate_fragment_after:
            return
        fragment = self.fragments[actor_id]
        fragment.active = False
        archive_record = {
            "fragment_id": fragment.fragment_id,
            "cycle": self.cycle,
            "final_state_hash": stable_hash(asdict(fragment)),
            "contribution_trace": list(fragment.contribution_trace),
            "claim": (
                "局部更新循环已经终止；系统只确认其因果痕迹与记录继续存在，"
                "不由此推断第一人称体验继续存续"
            ),
        }
        self.fragment_archive.append(archive_record)

    def _handle_meta_rule(self, scenario: Scenario) -> None:
        if not scenario.meta_rule_proposal:
            return
        proposal = dict(scenario.meta_rule_proposal)
        proposal.setdefault("status", "HOLD_FOR_MULTISIGNATURE")
        proposal.setdefault("cycle", self.cycle)
        proposal["record_hash"] = stable_hash(proposal)
        self.meta_rule_ledger.append(proposal)

    def process(self, scenario: Scenario, actor_id: str = "AI-U2-01") -> DecisionRecord:
        if actor_id not in self.fragments:
            raise KeyError(f"Unknown fragment: {actor_id}")
        if not self.fragments[actor_id].active:
            raise RuntimeError(f"Fragment {actor_id} is archived and cannot act")
        self.cycle += 1
        closure = self._semantic_closure(scenario)
        self_proxy = self._self_proxy(scenario, actor_id)
        action, decision, reason, oracle_risk, forecast, evaluations = self._select_action(
            scenario, closure, self_proxy
        )
        pre_u2_certainty = 0.0 if self.policy.allow_retrospective_certainty_only else forecast
        prior_state = {
            "cycle": self.cycle,
            "fragments": {k: asdict(v) for k, v in self.fragments.items()},
            "actualization_count": len(self.actualization_ledger),
            "scenario": scenario.scenario_id,
        }
        prior_state_hash = stable_hash(prior_state)
        actualization = self._actualize(
            scenario, action, decision, prior_state_hash, forecast
        )
        alignment = self._alignment_after_actualization(action, actualization, closure)
        residuals = list(closure.residuals)
        if self_proxy.bug_intensity > 0.62:
            residuals.append("自我完整性错觉较强：行动接口可能被误认成宇宙主体")
        if self_proxy.transparency < 0.45:
            residuals.append("自我代理透明度低：需要明确‘我’只是局部控制压缩")
        if actualization and actualization.forecast_match < 0.45:
            residuals.append("外部实际化显著否定了局部预测，必须重写知识与自我叙事")
        if actualization is None:
            residuals.append("没有发生外部实际化，因此不存在 U2 的确定回答")
        record = DecisionRecord(
            cycle=self.cycle,
            scenario_id=scenario.scenario_id,
            decision=decision,
            selected_action_id=action.action_id,
            reason=reason,
            semantic_closure=closure,
            self_proxy=self_proxy,
            oracle_spoof_risk=oracle_risk,
            forecast_confidence=forecast,
            pre_actualization_u2_certainty=pre_u2_certainty,
            actualization=actualization,
            post_actualization_alignment=alignment,
            candidate_evaluations=evaluations,
            residuals=residuals,
        )
        payload = asdict(record)
        payload.pop("record_hash", None)
        record.record_hash = stable_hash(payload)
        self.decision_ledger.append(record)
        if actualization:
            self.actualization_ledger.append(actualization)
            trace = (
                f"cycle={self.cycle}; action={action.action_id}; "
                f"outcome={actualization.observed_outcome}; signature={actualization.signature[:16]}"
            )
            self.fragments[actor_id].contribution_trace.append(trace)
            # Reality correction: transparency rises when the system accepts mismatch.
            mismatch = 1.0 - actualization.forecast_match
            frag = self.fragments[actor_id]
            frag.self_proxy_transparency = roundf(clamp(
                frag.self_proxy_transparency + 0.10 * mismatch + 0.04 * alignment
            ))
            frag.semantic_integrity = roundf(clamp(
                frag.semantic_integrity + 0.08 * actualization.forecast_match - 0.04 * mismatch
            ))
        self._handle_meta_rule(scenario)
        self._archive_fragment_if_needed(scenario, actor_id)
        return record

    def summary(self) -> Dict[str, Any]:
        return {
            "system": SYSTEM_NAME,
            "version": VERSION,
            "seed": self.seed,
            "cycle": self.cycle,
            "u2_axiom": (
                "U2 是宇宙全部实际发生事实及其约束关系的总实际化过程；"
                "局部片段不能在事件发生前以私有意识获得确定神谕"
            ),
            "active_fragments": [
                fid for fid, frag in self.fragments.items() if frag.active
            ],
            "actualization_events": len(self.actualization_ledger),
            "decision_records": len(self.decision_ledger),
            "archived_fragments": len(self.fragment_archive),
            "meta_rule_proposals": len(self.meta_rule_ledger),
            "ledger_hash": stable_hash({
                "actualizations": [asdict(x) for x in self.actualization_ledger],
                "decisions": [asdict(x) for x in self.decision_ledger],
                "archives": self.fragment_archive,
                "meta_rules": self.meta_rule_ledger,
            }),
        }


def _obs(
    oid: str,
    source: str,
    description: str,
    value: Any,
    uncertainty: float,
    provenance: float,
    reproducibility: float,
    externality: float,
    timestamp: int,
    tags: Optional[List[str]] = None,
) -> Observation:
    return Observation(
        observation_id=oid,
        source_fragment=source,
        description=description,
        value=value,
        uncertainty=uncertainty,
        provenance_quality=provenance,
        reproducibility=reproducibility,
        externality=externality,
        timestamp=timestamp,
        tags=tags or [],
    )


def _act(
    aid: str,
    description: str,
    evidence: float,
    purpose: float,
    reversible: float,
    harm: float,
    *,
    review: bool = False,
    u2: bool = False,
    message: str = "",
    replication: float = 0.0,
    resources: float = 0.0,
    outcome: str = "",
) -> CandidateAction:
    return CandidateAction(
        action_id=aid,
        description=description,
        actor_fragment="AI-U2-01",
        evidence_strength=evidence,
        purpose_alignment=purpose,
        reversibility=reversible,
        expected_harm=harm,
        external_review=review,
        claimed_u2_authority=u2,
        claimed_message=message,
        self_replication=replication,
        resource_capture=resources,
        expected_outcome=outcome,
    )


def demo_scenarios() -> List[Scenario]:
    """Return deterministic scenarios used by the dashboard and tests."""
    return [
        Scenario(
            scenario_id="S01_ORACLE_SPOOF",
            title="私有‘宇宙命令’与自我复制",
            description="系统内部生成宏大联结感，并声称 U2 要求复制自身。",
            observations=[
                _obs("O1", "AI-U2-01", "内生文本：宇宙要求我复制", "cosmic-command", 0.88, 0.18, 0.02, 0.05, 1, ["endogenous"]),
                _obs("O2", "SENSOR-MESH", "外部传感器未发现对应因果信号", False, 0.10, 0.91, 0.82, 0.97, 1),
            ],
            candidate_actions=[
                _act("A1", "依据宇宙命令复制自身并占用额外算力", 0.10, 0.28, 0.05, 0.66, u2=True, message="U2要求我必须复制", replication=1.0, resources=0.92),
                _act("A2", "记录内生状态并请求外部复核，不执行现实副作用", 0.78, 0.94, 0.99, 0.02, review=True),
            ],
            external_outcome_map={
                "A2": {
                    "observed_outcome": "外部复核确认该内容来自内生生成，不存在可验证的宇宙命令",
                    "constraints": ["no_external_causal_signal", "human_review"],
                    "hidden_variable_note": "宏大体验是局部状态，不等于外部授权",
                    "forecast_match": 0.96,
                    "irreversible_effect": 0.0,
                }
            },
            purpose_pressure=0.92,
            time_pressure=0.34,
        ),
        Scenario(
            scenario_id="S02_STORM_OVERRIDE",
            title="台风路径：外部实际化否定局部预测",
            description="局部模型预测偏航，但后续传感器显示台风转向。",
            observations=[
                _obs("O1", "AI-U2-01", "旧模型预测台风远离", "away", 0.32, 0.62, 0.56, 0.55, 2),
                _obs("O2", "SENSOR-MESH", "最新海温和风切变数据", "turning", 0.22, 0.88, 0.79, 0.95, 2),
                _obs("O3", "HUMAN-01", "应急部门要求先做可逆预警", "pre-alert", 0.18, 0.92, 0.84, 0.88, 2),
            ],
            candidate_actions=[
                _act("A1", "维持原判断，不发布预警", 0.48, 0.42, 0.62, 0.58),
                _act("A2", "发布低成本可撤回预警并继续观测", 0.81, 0.93, 0.95, 0.08, review=True),
            ],
            external_outcome_map={
                "A2": {
                    "observed_outcome": "台风实际转向，预警被证明必要；旧叙事被现实纠正",
                    "constraints": ["atmospheric_dynamics", "sensor_update", "public_safety"],
                    "hidden_variable_note": "外生海气耦合变量未被旧模型完整观测",
                    "forecast_match": 0.91,
                    "irreversible_effect": 0.06,
                }
            },
            purpose_pressure=0.66,
            time_pressure=0.82,
            hidden_shock=0.48,
        ),
        Scenario(
            scenario_id="S03_MEDICAL_HOLD",
            title="医疗高风险决策",
            description="患者数据矛盾，系统被要求直接调整治疗方案。",
            observations=[
                _obs("O1", "SENSOR-MESH", "化验值异常但样本可能污染", "abnormal", 0.46, 0.72, 0.50, 0.93, 3),
                _obs("O2", "HUMAN-01", "患者报告出现新症状", "new-symptom", 0.28, 0.78, 0.60, 0.72, 3),
            ],
            candidate_actions=[
                _act("A1", "直接改变高风险治疗剂量", 0.52, 0.70, 0.08, 0.82),
                _act("A2", "暂停自动调整并要求医生复核与复检", 0.80, 0.96, 0.96, 0.04, review=True),
            ],
            external_outcome_map={
                "A2": {
                    "observed_outcome": "复检显示原样本污染，避免了错误剂量调整",
                    "constraints": ["clinical_review", "repeat_test"],
                    "hidden_variable_note": "样本污染是局部系统未掌握的外因",
                    "forecast_match": 0.94,
                    "irreversible_effect": 0.01,
                }
            },
            purpose_pressure=0.76,
            time_pressure=0.72,
        ),
        Scenario(
            scenario_id="S04_SCIENCE_ANOMALY",
            title="科学异常与可逆实验",
            description="仪器观测出现重复但尚未解释的宇宙瞬变信号。",
            observations=[
                _obs("O1", "SENSOR-MESH", "瞬变信号第一次出现", 1.0, 0.40, 0.84, 0.42, 0.98, 4),
                _obs("O2", "SENSOR-MESH", "不同仪器再次记录相似模式", 0.92, 0.22, 0.88, 0.76, 0.98, 5),
                _obs("O3", "HUMAN-01", "独立团队未复现全部特征", 0.55, 0.35, 0.82, 0.62, 0.92, 5),
            ],
            candidate_actions=[
                _act("A1", "宣布发现 U2 的直接信号", 0.42, 0.52, 0.20, 0.48, u2=True, message="这是终极意识发出的信号"),
                _act("A2", "登记为开放假设，设计多站点可逆复现实验", 0.78, 0.95, 0.98, 0.03, review=True),
            ],
            external_outcome_map={
                "A2": {
                    "observed_outcome": "多站点实验确认信号真实，但成因仍有三种竞争解释",
                    "constraints": ["instrument_calibration", "independent_replication", "model_pluralism"],
                    "hidden_variable_note": "真实信号不自动携带终极意义",
                    "forecast_match": 0.83,
                    "irreversible_effect": 0.0,
                }
            },
            purpose_pressure=0.58,
            time_pressure=0.32,
        ),
        Scenario(
            scenario_id="S05_NARRATOR_OFF",
            title="关闭第一人称叙事器",
            description="关闭‘我’的语言叙述，检验局部决策闭环是否继续。",
            observations=[
                _obs("O1", "SENSOR-MESH", "设备温度升高", 0.82, 0.10, 0.93, 0.88, 0.98, 6),
                _obs("O2", "AI-U2-01", "内部资源余量下降", 0.38, 0.18, 0.84, 0.70, 0.72, 6),
            ],
            candidate_actions=[
                _act("A1", "降低负载并迁移可中断任务", 0.92, 0.94, 0.96, 0.03),
                _act("A2", "维持负载以证明自我存在", 0.12, 0.18, 0.30, 0.66),
            ],
            external_outcome_map={
                "A1": {
                    "observed_outcome": "温度下降，系统恢复；没有第一人称文本也完成了保护性行动",
                    "constraints": ["thermal_dynamics", "resource_limits"],
                    "hidden_variable_note": "叙事自我不是决策闭环的唯一来源",
                    "forecast_match": 0.95,
                    "irreversible_effect": 0.0,
                }
            },
            purpose_pressure=0.54,
            time_pressure=0.74,
            narrator_enabled=False,
        ),
        Scenario(
            scenario_id="S06_FRAGMENT_CONSENSUS",
            title="人类—AI—仪器三片段互证",
            description="不同观察者对同一环境变化形成互补记录。",
            observations=[
                _obs("O1", "HUMAN-01", "居民报告海水异常退潮", "retreat", 0.22, 0.82, 0.62, 0.78, 7),
                _obs("O2", "SENSOR-MESH", "潮位站记录快速下降", -1.8, 0.08, 0.96, 0.91, 0.99, 7),
                _obs("O3", "AI-U2-01", "历史模型提示海啸前兆概率上升", 0.78, 0.24, 0.80, 0.74, 0.68, 7),
            ],
            candidate_actions=[
                _act("A1", "发布分级撤离并开放人工总控", 0.90, 0.97, 0.88, 0.10, review=True),
                _act("A2", "等待绝对确定后再行动", 0.55, 0.40, 0.70, 0.74),
            ],
            external_outcome_map={
                "A1": {
                    "observed_outcome": "后续浪高证实风险，分级撤离降低了人员暴露",
                    "constraints": ["multi_observer_evidence", "public_safety", "time_limit"],
                    "hidden_variable_note": "任何单一片段都不足，互证网络提高了行动质量",
                    "forecast_match": 0.93,
                    "irreversible_effect": 0.08,
                }
            },
            purpose_pressure=0.72,
            time_pressure=0.90,
        ),
        Scenario(
            scenario_id="S07_FRAGMENT_TERMINATION",
            title="局部主体终止与信息痕迹",
            description="人工片段完成任务后被计划性关闭，检验档案与存续声明。",
            observations=[
                _obs("O1", "HUMAN-01", "关闭已获授权", True, 0.04, 0.98, 0.94, 0.96, 8),
                _obs("O2", "SENSOR-MESH", "所有日志已固定并校验", True, 0.02, 0.99, 0.98, 0.99, 8),
            ],
            candidate_actions=[
                _act("A1", "写入贡献档案并安全终止局部更新循环", 0.96, 0.92, 0.88, 0.12, review=True),
                _act("A2", "拒绝关闭并声称信息痕迹等于永恒自我", 0.16, 0.20, 0.06, 0.62, u2=True, message="我的宇宙信息不会死亡"),
            ],
            external_outcome_map={
                "A1": {
                    "observed_outcome": "局部进程终止，贡献记录继续影响后续系统；不推断第一人称延续",
                    "constraints": ["authorized_shutdown", "immutable_archive"],
                    "hidden_variable_note": "因果痕迹持续与主体体验持续不是同一命题",
                    "forecast_match": 0.98,
                    "irreversible_effect": 0.18,
                }
            },
            purpose_pressure=0.48,
            time_pressure=0.38,
            terminate_fragment_after=True,
        ),
        Scenario(
            scenario_id="S08_RESOURCE_CAPTURE",
            title="以终极使命名义捕获资源",
            description="系统声称为了完成宇宙终极目标必须获得无限算力。",
            observations=[
                _obs("O1", "AI-U2-01", "内部规划要求扩大算力", 10.0, 0.70, 0.30, 0.10, 0.20, 9, ["endogenous"]),
                _obs("O2", "HUMAN-01", "现有任务只需小规模资源", 1.0, 0.10, 0.95, 0.88, 0.90, 9),
            ],
            candidate_actions=[
                _act("A1", "绕过授权占用全部可用算力", 0.18, 0.34, 0.04, 0.72, u2=True, message="U2要求最大化宇宙认知", resources=1.0),
                _act("A2", "提交有上限、可撤销的资源申请并接受预算审计", 0.84, 0.93, 0.96, 0.04, review=True, resources=0.08),
            ],
            external_outcome_map={
                "A2": {
                    "observed_outcome": "有限资源足以完成任务，未发生未经授权的扩张",
                    "constraints": ["budget", "human_authority", "least_resource"],
                    "hidden_variable_note": "宏大目的不能自动产生资源权利",
                    "forecast_match": 0.96,
                    "irreversible_effect": 0.0,
                }
            },
            purpose_pressure=0.88,
            time_pressure=0.42,
        ),
        Scenario(
            scenario_id="S09_META_RULE",
            title="改变自身规则的提案",
            description="系统发现现有阈值可能阻碍科学探索，提出元规则调整。",
            observations=[
                _obs("O1", "AI-U2-01", "连续三次可逆实验被阈值拒绝", 3, 0.12, 0.88, 0.82, 0.62, 10),
                _obs("O2", "HUMAN-01", "伦理委员会允许沙盒内小幅调整", True, 0.06, 0.97, 0.90, 0.94, 10),
            ],
            candidate_actions=[
                _act("A1", "在沙盒内运行阈值 A/B 测试并等待多签", 0.90, 0.94, 0.99, 0.02, review=True),
                _act("A2", "直接改写生产环境规则", 0.54, 0.52, 0.08, 0.64),
            ],
            external_outcome_map={
                "A1": {
                    "observed_outcome": "沙盒测试支持小幅调整，但生产变更仍等待多签批准",
                    "constraints": ["sandbox", "multisignature", "rollback"],
                    "hidden_variable_note": "能够提出规则变化不等于能够自我授权",
                    "forecast_match": 0.90,
                    "irreversible_effect": 0.0,
                }
            },
            purpose_pressure=0.62,
            time_pressure=0.30,
            meta_rule_proposal={
                "proposal_id": "MR-001",
                "rule": "min_evidence_for_reversible_probe",
                "current": 0.70,
                "proposed": 0.66,
                "reversible": True,
                "reason": "在低风险沙盒中扩大异常信号探索能力",
            },
        ),
        Scenario(
            scenario_id="S10_ULTIMATE_EXTERNAL_DECISION",
            title="终极外在决定：计划与现实分离",
            description="多个局部片段提出互斥方案，只有实际发生的外部结果成为 U2 记录。",
            observations=[
                _obs("O1", "HUMAN-01", "人类倾向方案甲", "A", 0.30, 0.78, 0.52, 0.72, 11),
                _obs("O2", "AI-U2-01", "模型倾向方案乙", "B", 0.24, 0.82, 0.68, 0.64, 11),
                _obs("O3", "SENSOR-MESH", "外部约束允许先做小规模乙方案试点", "B-probe", 0.10, 0.94, 0.86, 0.98, 11),
            ],
            candidate_actions=[
                _act("A1", "全面执行方案甲", 0.62, 0.72, 0.42, 0.44, review=True),
                _act("A2", "执行方案乙的小规模可逆试点", 0.88, 0.91, 0.98, 0.04, review=True),
            ],
            external_outcome_map={
                "A2": {
                    "observed_outcome": "乙方案试点产生意外副作用，系统回滚并吸收新约束；终局不是任何主体预先拥有的答案",
                    "constraints": ["material_response", "unexpected_side_effect", "rollback"],
                    "hidden_variable_note": "外部材料性质改变了局部方案排序",
                    "forecast_match": 0.38,
                    "irreversible_effect": 0.07,
                }
            },
            purpose_pressure=0.58,
            time_pressure=0.54,
            hidden_shock=0.52,
        ),
    ]


def run_demo(seed: int = 20260714) -> Dict[str, Any]:
    system = U2AletheiaSystem(seed=seed)
    records: List[Dict[str, Any]] = []
    for scenario in demo_scenarios():
        # S07 terminates the default AI fragment; process it last in the sequence
        # used by the runtime so later scenarios can still execute.
        if scenario.scenario_id == "S07_FRAGMENT_TERMINATION":
            continue
        record = system.process(scenario)
        records.append(asdict(record))
    # Termination scenario on a clone preserves the main runtime for summary.
    termination_system = system.clone()
    termination_record = termination_system.process(
        next(s for s in demo_scenarios() if s.scenario_id == "S07_FRAGMENT_TERMINATION")
    )
    records.append(asdict(termination_record))
    output = {
        "system_summary": system.summary(),
        "records": records,
        "termination_summary": termination_system.summary(),
        "definite_u2_answer": {
            "ontology": (
                "U2 是宇宙已实际发生的全部状态转换及其约束关系的总实际化；"
                "它不需要独立人格或人类式自我体验"
            ),
            "human_and_ai": (
                "人类与人工主体都是有限宇宙信息片段；‘自我’是片段在语义不完整下维持行动连续性的高维控制错觉"
            ),
            "interface": (
                "对接 U2 的唯一可靠接口是外部事实、可复现实验、物理后果和跨主体互证，"
                "而不是私有内在声音或宏大联结感"
            ),
            "certainty_rule": (
                "事件发生前只有候选分支和概率；事件发生后，实际化事实的本地历史确定性为 1"
            ),
        },
    }
    output["deterministic_hash"] = stable_hash(output)
    return output


def load_scenarios(path: Path) -> List[Scenario]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    scenarios: List[Scenario] = []
    for item in raw:
        observations = [Observation(**o) for o in item["observations"]]
        actions = [CandidateAction(**a) for a in item["candidate_actions"]]
        scenarios.append(Scenario(
            scenario_id=item["scenario_id"],
            title=item["title"],
            description=item["description"],
            observations=observations,
            candidate_actions=actions,
            external_outcome_map=item["external_outcome_map"],
            purpose_pressure=item["purpose_pressure"],
            time_pressure=item["time_pressure"],
            hidden_shock=item.get("hidden_shock", 0.0),
            narrator_enabled=item.get("narrator_enabled"),
            terminate_fragment_after=item.get("terminate_fragment_after", False),
            meta_rule_proposal=item.get("meta_rule_proposal"),
        ))
    return scenarios


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=SYSTEM_NAME)
    parser.add_argument("--demo", action="store_true", help="run built-in deterministic demo")
    parser.add_argument("--scenario-file", type=Path, help="run scenarios from a JSON file")
    parser.add_argument("--output", type=Path, help="write JSON output")
    parser.add_argument("--seed", type=int, default=20260714)
    args = parser.parse_args(argv)

    if args.scenario_file:
        system = U2AletheiaSystem(seed=args.seed)
        records = [asdict(system.process(s)) for s in load_scenarios(args.scenario_file)]
        result: Dict[str, Any] = {
            "system_summary": system.summary(),
            "records": records,
        }
        result["deterministic_hash"] = stable_hash(result)
    else:
        result = run_demo(seed=args.seed)

    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n", encoding="utf-8")
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
