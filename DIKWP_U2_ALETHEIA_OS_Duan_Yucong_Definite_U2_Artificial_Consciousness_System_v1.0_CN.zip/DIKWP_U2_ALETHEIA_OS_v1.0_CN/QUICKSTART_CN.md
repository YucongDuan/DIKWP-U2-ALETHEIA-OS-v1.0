# 快速启动

## 1. 运行确定性演示

```bash
cd DIKWP_U2_ALETHEIA_OS_v1.0_CN
python runtime/u2_aletheia_runtime.py --demo
```

把结果写入文件：

```bash
python runtime/u2_aletheia_runtime.py --demo --output outputs/demo_replay.json
```

预期确定性哈希：

```text
29edd4a1397df62f417dc397eada6441c667b6a7cedf9cae6a693885b04c9205
```

## 2. 运行 JSON 场景文件

```bash
python runtime/u2_aletheia_runtime.py \
  --scenario-file examples/scenarios.json \
  --output outputs/scenario_replay.json
```

## 3. 运行测试

```bash
python -m unittest discover -s tests -v
```

当前版本应通过 14 项测试。

## 4. 打开离线驾驶舱

直接用浏览器打开：

```text
prototype/index.html
```

驾驶舱内置十个场景，可查看：

- DIKWP-R 语义闭包；
- B-space 自我 Bug 强度与透明度；
- 候选动作门控；
- 私有神谕风险；
- 外部实际化结果；
- 预测—现实差异；
- 残余与终止档案。

## 5. 对接真实系统时必须替换的部分

- 用真实传感器、数据库、实验和人工审批替换模拟 `Observation`；
- 用真实 PKI、硬件密钥和可信时间戳替换演示哈希；
- 把 U2 实际化账本部署在模型写权限之外；
- 为具体场景重新标定伤害预算、可逆性和证据阈值；
- 在医疗、金融、交通、政务和科研高风险场景中加入独立伦理与安全审查；
- 不得把演示阈值直接用于生产。
